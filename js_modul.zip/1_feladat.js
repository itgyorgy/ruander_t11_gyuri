

<script>

    function KockaFelszin(a) {
        let kockaFelszin = Number(6 * (a ** 2));
    return kockaFelszin;
    }

    function Kiirato(szoveg, szam) {
        document.write(szoveg + ":" + szam + "<br>");
    }

    Kiirato("A 2 egységnyi oldalú kocka felszíne", KockaFelszin(2));
    Kiirato("A 3 egységnyi oldalú kocka felszíne", KockaFelszin(3));
    Kiirato("Az 5 egységnyi oldalú kocka felszíne", KockaFelszin(5));

</script>
