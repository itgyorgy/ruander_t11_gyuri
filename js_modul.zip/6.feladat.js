

<script>

    function MaganHangzokSzama(vizsgaltSzoveg) {
        let maganhangzodb = [];
    let maganHangzok = ["a", "á", "e", "é", "i", "í", "o", "ó", "ö", "ő", "u", "ú", "ü", "ű", "A", "Á", "E", "É", "I", "Í", "O", "Ó", "Ö", "Ő", "U", "Ú", "Ü", "Ű"];
    for (let i = 0; i < vizsgaltSzoveg.length; i++) {
            for (let j = 0; j < maganHangzok.length; j++) {
                if (vizsgaltSzoveg[i] == maganHangzok[j]) {
        maganhangzodb += (vizsgaltSzoveg[i]);
                }
            }
        }
    return maganhangzodb.length;
    }

    function Kiirato(szoveg, szam) {
        document.write(szoveg + ":" + szam + "<br>");
    }

    Kiirato("A magánhangzók száma", MaganHangzokSzama("Szeretem a programozás"));
    Kiirato("A magánhangzók száma", MaganHangzokSzama("Géza kék az ég"));
    Kiirato("A magánhangzók száma", MaganHangzokSzama("Répa, retek, mogyoró"));

</script>

