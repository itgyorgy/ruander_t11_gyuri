

<script>

    function KockaTerfogat(a) {
        let kockaTerfogat = Number(a * a * a);
    return kockaTerfogat;
    }

    function Kiirato(szoveg, szam) {
        document.write(szoveg + ":" + szam + "<br>");
    }

    Kiirato("A 2 egységnyi oldalú kocka térfogata", KockaTerfogat(2));
    Kiirato("A 3 egységnyi oldalú kocka térfogata", KockaTerfogat(3));
    Kiirato("Az 5 egységnyi oldalú kocka térfogata", KockaTerfogat(5));

</script>

