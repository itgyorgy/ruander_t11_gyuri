
<script>

    let vizsgaltErtek = 0;
    function PhErtek(vizsgaltErtek) {
        if (vizsgaltErtek < 7) {
            return "savas";
        } else
    if (vizsgaltErtek == 7) {
                return "semleges";
            } else
                if (vizsgaltErtek > 7) {
                    return "lugos";
                }
    }

    function Kiirato(szoveg, szam) {
        document.write(szoveg + ": " + szam + "<br>");
    }

    Kiirato("A 9 PH érték", PhErtek(9));
    Kiirato("Az 5.5 PH érték", PhErtek(5.5));
    Kiirato("A 7 PH érték", PhErtek(7));


</script>

