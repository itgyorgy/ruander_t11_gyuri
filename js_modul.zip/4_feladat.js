

<script>

    let tomb = [];
    function ElsoNSzamOsszegee(szamokMenyisege) {
        let szamokMenyisege = 0;
    for (let i = 0; i < tomb.length; i++) {
        szamokMenyisege = szamokMenyisege + tomb[i];
        }
    return szamokMenyisege;
    }

    function Kiirato(szoveg, szam) {
        document.write(szoveg + ":" + szam + "<br>");
    }

    Kiirato("A számok összege 3 esetén", ElsoNSzamOsszege(3));
    Kiirato("A számok összege 10 esetén", ElsoNSzamOsszege(10));
    Kiirato("Aszámok összege 21 esetén", ElsoNSzamOsszege(21));

</script>

