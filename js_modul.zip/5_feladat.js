
<script>

    function MaxParos(vizsgaltTomb) {
        let maxErtek = vizsgaltTomb[0];
    for (let i = 0; i < vizsgaltTomb.length; i++) {
            if (vizsgaltTomb[i] % 2 == 0 && vizsgaltTomb[i] > maxErtek) {
        maxErtek = vizsgaltTomb[i];
            }
        }
    return maxErtek;
    }

    function Kiirato(szoveg, szam) {
        document.write(szoveg + ": " + szam + "<br>");
    }

    Kiirato("A legnagyobb páros szám", MaxParos([12, 3, 7, 19, 21]));
    Kiirato("Az legnagyobb páros szám", MaxParos([28, 14, 2, 42, 69]));
    Kiirato("A legnagyobb páros szám", MaxParos([32, 21, 54, 33, 21]));


    document.write("<hr>A tömb legnagyobb elemének értéke: " + maxErtek);


</script>
